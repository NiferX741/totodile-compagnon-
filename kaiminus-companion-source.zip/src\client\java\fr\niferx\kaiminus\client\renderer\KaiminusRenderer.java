package fr.niferx.kaiminus.client.renderer;

import org.joml.Matrix4f;

import com.mojang.blaze3d.vertex.PoseStack;

import fr.niferx.kaiminus.KaiminusMod;
import fr.niferx.kaiminus.client.model.KaiminusModel;
import fr.niferx.kaiminus.client.model.KaiminusRig;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.rendertype.RenderType;
import net.minecraft.client.renderer.rendertype.RenderTypes;
import net.minecraft.client.renderer.state.level.CameraRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.util.ARGB;
import net.minecraft.util.Mth;

/**
 * Dessine le GLB skinné. Le modèle en cubes reste le repli si le fichier
 * ne se charge pas.
 */
public class KaiminusRenderer extends MobRenderer<KaiminusCompanion, KaiminusRenderState, KaiminusModel> {
	private static final Identifier TEXTURE = KaiminusMod.id("textures/entity/kaiminus.png");

	public KaiminusRenderer(EntityRendererProvider.Context context) {
		super(context, new KaiminusModel(context.bakeLayer(KaiminusModel.LAYER)), 0.6F);
	}

	@Override
	public KaiminusRenderState createRenderState() {
		return new KaiminusRenderState();
	}

	@Override
	public Identifier getTextureLocation(KaiminusRenderState state) {
		return TEXTURE;
	}

	@Override
	public void extractRenderState(KaiminusCompanion entity, KaiminusRenderState state, float partialTick) {
		super.extractRenderState(entity, state, partialTick);
		state.swimming = entity.isInWater();
		state.sitting = entity.isInSittingPose();
		var move = entity.getDeltaMovement();
		state.moveSpeed = (float) Math.sqrt(move.x * move.x + move.z * move.z);
		state.biteAnimation.copyFrom(entity.biteAnimation);
		state.tailAnimation.copyFrom(entity.tailAnimation);
		state.waterJetAnimation.copyFrom(entity.waterJetAnimation);
	}

	@Override
	public void submit(KaiminusRenderState state, PoseStack pose, SubmitNodeCollector collector, CameraRenderState camera) {
		KaiminusRig rig = KaiminusRig.get();
		if (rig == null) {
			super.submit(state, pose, collector, camera);
			return;
		}
		boolean bodyVisible = this.isBodyVisible(state);
		if (bodyVisible || !state.isInvisibleToPlayer) {
			int color = ARGB.multiply(bodyVisible ? 0xFFFFFFFF : 0x26FFFFFF, this.getModelTint(state));
			int overlay = LivingEntityRenderer.getOverlayCoords(state, this.getWhiteOverlayProgress(state));
			RenderType renderType = bodyVisible ? RenderTypes.entityCutout(TEXTURE) : RenderTypes.entityTranslucent(TEXTURE);
			pose.pushPose();
			pose.scale(state.scale, state.scale, state.scale);
			this.setupRotations(state, pose, state.bodyRot, state.scale);
			pose.mulPose(new Matrix4f().rotationY(Mth.PI));
			this.scale(state, pose);
			collector.submitCustomGeometry(pose, renderType, (modelPose, consumer) ->
					rig.render(state, modelPose, consumer, color, overlay, state.lightCoords));
			pose.popPose();
		}
		if (state.leashStates != null) {
			for (var leash : state.leashStates) {
				collector.submitLeash(pose, leash);
			}
		}
		this.submitNameDisplay(state, pose, collector, camera);
	}
}
