package fr.niferx.kaiminus.entity.ai;

import java.util.EnumSet;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.CompanionOrder;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Suit le propriétaire entre {@code followStopDistance} et {@code followStartDistance}.
 * Accélère s'il s'éloigne, et se téléporte s'il est trop loin ou si le chemin ne progresse plus.
 */
public class CompanionFollowGoal extends Goal {
	private final KaiminusCompanion companion;
	private LivingEntity owner;
	private int repathCooldown;
	private int stuckTicks;
	private double lastDistanceSqr = Double.MAX_VALUE;

	public CompanionFollowGoal(KaiminusCompanion companion) {
		this.companion = companion;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		if (this.companion.getOrder() != CompanionOrder.FOLLOW || this.companion.isOrderedToSit()) {
			return false;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		if (owner == null || owner.isSpectator() || owner.level() != this.companion.level()) {
			return false;
		}
		if (this.companion.getTarget() != null) {
			return false;
		}
		this.owner = owner;
		return this.companion.distanceToSqr(owner) > square(CompanionConfig.followStartDistance);
	}

	@Override
	public boolean canContinueToUse() {
		if (this.owner == null || !this.owner.isAlive() || this.companion.getOrder() != CompanionOrder.FOLLOW) {
			return false;
		}
		if (this.companion.getTarget() != null || this.companion.isOrderedToSit()) {
			return false;
		}
		return this.companion.distanceToSqr(this.owner) > square(CompanionConfig.followStopDistance);
	}

	@Override
	public void start() {
		this.repathCooldown = 0;
		this.stuckTicks = 0;
		this.lastDistanceSqr = this.companion.distanceToSqr(this.owner);
	}

	@Override
	public void stop() {
		this.owner = null;
		this.companion.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (this.owner == null) {
			return;
		}
		this.companion.getLookControl().setLookAt(this.owner, 30.0F, 30.0F);
		double distanceSqr = this.companion.distanceToSqr(this.owner);
		if (distanceSqr > square(CompanionConfig.teleportDistance) || this.stuckTicks > 40) {
			this.companion.teleportNearOwner(this.owner);
			this.stuckTicks = 0;
			this.lastDistanceSqr = this.companion.distanceToSqr(this.owner);
			return;
		}
		if (distanceSqr >= this.lastDistanceSqr - 0.05) {
			this.stuckTicks++;
		} else {
			this.stuckTicks = 0;
		}
		this.lastDistanceSqr = distanceSqr;

		if (--this.repathCooldown > 0) {
			return;
		}
		this.repathCooldown = this.adjustedTickDelay(8);
		this.companion.getNavigation().moveTo(this.owner, this.speedFor(distanceSqr));
	}

	private double speedFor(double distanceSqr) {
		if (this.companion.isInWater()) {
			return CompanionConfig.swimSpeed;
		}
		if (distanceSqr > square(10.0)) {
			return CompanionConfig.sprintSpeed;
		}
		return CompanionConfig.followSpeed;
	}

	private static double square(double value) {
		return value * value;
	}
}
