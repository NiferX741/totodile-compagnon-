package fr.niferx.kaiminus.entity.ai;

import java.util.EnumSet;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.CompanionOrder;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;

/**
 * Petit va-et-vient quand le propriétaire est immobile (suivi),
 * ou autour du point de garde (ordre garde).
 */
public class CompanionPatrolGoal extends Goal {
	private final KaiminusCompanion companion;
	private int cooldown;
	private double wantedX;
	private double wantedY;
	private double wantedZ;

	public CompanionPatrolGoal(KaiminusCompanion companion) {
		this.companion = companion;
		this.setFlags(EnumSet.of(Flag.MOVE));
	}

	@Override
	public boolean canUse() {
		if (!this.mayPatrol()) {
			return false;
		}
		if (--this.cooldown > 0) {
			return false;
		}
		this.cooldown = this.adjustedTickDelay(60 + this.companion.getRandom().nextInt(40));
		return this.pickDestination();
	}

	@Override
	public boolean canContinueToUse() {
		return this.mayPatrol() && !this.companion.getNavigation().isDone();
	}

	private boolean mayPatrol() {
		if (this.companion.isOrderedToSit() || this.companion.getTarget() != null) {
			return false;
		}
		CompanionOrder order = this.companion.getOrder();
		if (order == CompanionOrder.GUARD) {
			return true;
		}
		if (order != CompanionOrder.FOLLOW) {
			return false;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		if (owner == null) {
			return false;
		}
		double dx = owner.getX() - owner.xo;
		double dz = owner.getZ() - owner.zo;
		return dx * dx + dz * dz < 0.0008 && this.companion.distanceToSqr(owner) < 16.0;
	}

	@Override
	public void start() {
		double speed = this.companion.isInWater() ? CompanionConfig.swimSpeed * 0.7 : 0.75;
		this.companion.getNavigation().moveTo(this.wantedX, this.wantedY, this.wantedZ, speed);
	}

	@Override
	public void stop() {
		this.companion.getNavigation().stop();
	}

	private boolean pickDestination() {
		BlockPos center;
		double radius;
		if (this.companion.getOrder() == CompanionOrder.GUARD) {
			center = this.companion.getGuardAnchor();
			radius = CompanionConfig.guardPatrolRadius;
		} else {
			LivingEntity owner = this.companion.getOwnerLiving();
			if (owner == null) {
				return false;
			}
			center = owner.blockPosition();
			radius = CompanionConfig.patrolRadius;
		}
		int dx = this.companion.getRandom().nextInt((int) (radius * 2.0) + 1) - (int) radius;
		int dz = this.companion.getRandom().nextInt((int) (radius * 2.0) + 1) - (int) radius;
		this.wantedX = center.getX() + dx + 0.5;
		this.wantedY = center.getY();
		this.wantedZ = center.getZ() + dz + 0.5;
		return true;
	}
}
