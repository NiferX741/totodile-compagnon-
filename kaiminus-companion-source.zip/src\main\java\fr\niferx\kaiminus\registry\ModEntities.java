package fr.niferx.kaiminus.registry;

import fr.niferx.kaiminus.KaiminusMod;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;

public final class ModEntities {
	public static final ResourceKey<EntityType<?>> KAIMINUS_KEY = ResourceKey.create(Registries.ENTITY_TYPE, KaiminusMod.id("kaiminus"));

	public static final EntityType<KaiminusCompanion> KAIMINUS = register(
			KAIMINUS_KEY,
			EntityType.Builder.of(KaiminusCompanion::new, MobCategory.CREATURE)
					.sized(1.2F, 1.75F)
					.eyeHeight(1.42F)
					.clientTrackingRange(10),
			KaiminusCompanion.createAttributes()
	);

	private ModEntities() {
	}

	private static <T extends Entity> EntityType<T> register(ResourceKey<EntityType<?>> key, EntityType.Builder<T> builder) {
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key, builder.build(key));
	}

	private static <T extends LivingEntity> EntityType<T> register(ResourceKey<EntityType<?>> key, EntityType.Builder<T> builder, AttributeSupplier.Builder attributes) {
		EntityType<T> type = register(key, builder);
		FabricDefaultAttributeRegistry.register(type, attributes);
		return type;
	}

	public static void initialize() {
	}
}
