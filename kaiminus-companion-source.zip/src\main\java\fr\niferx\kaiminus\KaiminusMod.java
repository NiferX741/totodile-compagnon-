package fr.niferx.kaiminus;

import fr.niferx.kaiminus.registry.ModBlocks;
import fr.niferx.kaiminus.registry.ModEntities;
import fr.niferx.kaiminus.registry.ModItems;
import fr.niferx.kaiminus.registry.ModLoot;
import fr.niferx.kaiminus.registry.ModSounds;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public final class KaiminusMod implements ModInitializer {
	public static final String MOD_ID = "kaiminus_companion";

	@Override
	public void onInitialize() {
		ModSounds.initialize();
		ModEntities.initialize();
		ModBlocks.initialize();
		ModItems.initialize();
		ModLoot.initialize();
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
