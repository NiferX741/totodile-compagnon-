package fr.niferx.kaiminus.registry;

import fr.niferx.kaiminus.KaiminusMod;
import fr.niferx.kaiminus.block.KaiminusEggBlock;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModBlocks {
	public static final ResourceKey<Block> KAIMINUS_EGG_KEY = ResourceKey.create(Registries.BLOCK, KaiminusMod.id("kaiminus_egg"));

	public static final Block KAIMINUS_EGG = Registry.register(
			BuiltInRegistries.BLOCK,
			KAIMINUS_EGG_KEY,
			new KaiminusEggBlock(BlockBehaviour.Properties.of()
					.setId(KAIMINUS_EGG_KEY)
					.mapColor(DyeColor.LIGHT_BLUE)
					.strength(0.5F)
					.sound(SoundType.FROGSPAWN)
					.noOcclusion())
	);

	private ModBlocks() {
	}

	public static void initialize() {
	}
}
