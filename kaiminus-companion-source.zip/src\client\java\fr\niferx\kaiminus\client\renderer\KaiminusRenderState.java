package fr.niferx.kaiminus.client.renderer;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.world.entity.AnimationState;

/**
 * Données copiées de l'entité vers le fil de rendu.
 * Ajouter ici tout flag utile au modèle (ordre, nage, attaque).
 */
public class KaiminusRenderState extends LivingEntityRenderState {
	public boolean swimming;
	public boolean sitting;
	public float moveSpeed;
	public final AnimationState biteAnimation = new AnimationState();
	public final AnimationState tailAnimation = new AnimationState();
	public final AnimationState waterJetAnimation = new AnimationState();
}
