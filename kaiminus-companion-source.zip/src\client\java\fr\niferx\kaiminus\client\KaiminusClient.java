package fr.niferx.kaiminus.client;

import fr.niferx.kaiminus.client.model.KaiminusModel;
import fr.niferx.kaiminus.client.renderer.KaiminusRenderer;
import fr.niferx.kaiminus.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.renderer.entity.EntityRenderers;

public final class KaiminusClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		ModelLayerRegistry.registerModelLayer(KaiminusModel.LAYER, KaiminusModel::createBodyLayer);
		EntityRenderers.register(ModEntities.KAIMINUS, KaiminusRenderer::new);
	}
}
