package fr.niferx.kaiminus.block;

import fr.niferx.kaiminus.entity.KaiminusCompanion;
import fr.niferx.kaiminus.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.pathfinder.PathComputationType;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Œuf à poser. Il se fend en trois temps, puis un Kaiminus en sort.
 * Près de l'eau ou sur du sable, chaque étape est plus courte.
 */
public class KaiminusEggBlock extends Block {
	public static final IntegerProperty HATCH = BlockStateProperties.HATCH;
	public static final int MAX_HATCH_LEVEL = 2;
	private static final int STAGE_TICKS = 1200;
	private static final int FAST_STAGE_TICKS = 400;
	private static final VoxelShape SHAPE = Block.column(14.0, 12.0, 0.0, 16.0);

	public KaiminusEggBlock(Properties properties) {
		super(properties);
		this.registerDefaultState(this.stateDefinition.any().setValue(HATCH, 0));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(HATCH);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	@Override
	public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean movedByPiston) {
		if (!level.isClientSide()) {
			level.scheduleTick(pos, this, this.stageDelay(level, pos));
		}
	}

	@Override
	public void tick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		if (state.getValue(HATCH) < MAX_HATCH_LEVEL) {
			level.playSound(null, pos, SoundEvents.SNIFFER_EGG_CRACK, SoundSource.BLOCKS, 0.7F, 0.9F + random.nextFloat() * 0.2F);
			level.setBlock(pos, state.setValue(HATCH, state.getValue(HATCH) + 1), Block.UPDATE_CLIENTS);
			return;
		}
		level.playSound(null, pos, SoundEvents.SNIFFER_EGG_HATCH, SoundSource.BLOCKS, 0.7F, 0.9F + random.nextFloat() * 0.2F);
		level.destroyBlock(pos, false);
		KaiminusCompanion companion = ModEntities.KAIMINUS.create(level, EntitySpawnReason.BREEDING);
		if (companion == null) {
			return;
		}
		Vec3 center = Vec3.atBottomCenterOf(pos);
		companion.snapTo(center.x(), center.y(), center.z(), random.nextFloat() * 360.0F, 0.0F);
		companion.finalizeSpawn(level, level.getCurrentDifficultyAt(pos), EntitySpawnReason.BREEDING, null);
		level.addFreshEntity(companion);
	}

	@Override
	public boolean isPathfindable(BlockState state, PathComputationType type) {
		return false;
	}

	private int stageDelay(Level level, BlockPos pos) {
		int base = hatchesFaster(level, pos) ? FAST_STAGE_TICKS : STAGE_TICKS;
		return base + level.getRandom().nextInt(200);
	}

	private static boolean hatchesFaster(Level level, BlockPos pos) {
		if (level.getBlockState(pos.below()).is(BlockTags.SAND) || level.getFluidState(pos).is(FluidTags.WATER)) {
			return true;
		}
		for (Direction direction : Direction.Plane.HORIZONTAL) {
			if (level.getFluidState(pos.relative(direction)).is(FluidTags.WATER)) {
				return true;
			}
		}
		return false;
	}
}
