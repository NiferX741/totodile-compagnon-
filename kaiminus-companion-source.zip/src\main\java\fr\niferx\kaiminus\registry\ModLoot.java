package fr.niferx.kaiminus.registry;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.Holder;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.storage.loot.BuiltInLootTables;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.LootTable;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;
import net.minecraft.world.level.storage.loot.providers.number.ints.ConstantValue;

public final class ModLoot {
	private ModLoot() {
	}

	public static void initialize() {
		LootTableEvents.MODIFY.register((key, table, source, registries) -> {
			if (!source.isBuiltin()) {
				return;
			}
			Float chance = chanceFor(key);
			if (chance == null) {
				return;
			}
			table.withPool(LootPool.lootPool()
					.setRolls(Holder.direct(new ConstantValue(1)))
					.when(LootItemRandomChanceCondition.randomChance(chance).build())
					.add(LootItem.lootTableItem(ModItems.KAIMINUS_EGG)));
		});
	}

	private static Float chanceFor(ResourceKey<LootTable> key) {
		if (key == BuiltInLootTables.SHIPWRECK_TREASURE || key == BuiltInLootTables.UNDERWATER_RUIN_BIG) {
			return 0.08F;
		}
		if (key == BuiltInLootTables.UNDERWATER_RUIN_SMALL) {
			return 0.04F;
		}
		if (key == BuiltInLootTables.SHIPWRECK_SUPPLY) {
			return 0.03F;
		}
		if (key == BuiltInLootTables.SHIPWRECK_MAP) {
			return 0.02F;
		}
		return null;
	}
}
