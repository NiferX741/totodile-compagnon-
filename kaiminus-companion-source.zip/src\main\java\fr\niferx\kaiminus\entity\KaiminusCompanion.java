package fr.niferx.kaiminus.entity;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.ai.CompanionAttackGoal;
import fr.niferx.kaiminus.entity.ai.CompanionFollowGoal;
import fr.niferx.kaiminus.entity.ai.CompanionPatrolGoal;
import fr.niferx.kaiminus.entity.ai.InterposeGoal;
import fr.niferx.kaiminus.entity.ai.KaiminusNavigation;
import fr.niferx.kaiminus.entity.ai.ProtectOwnerTargetGoal;
import fr.niferx.kaiminus.registry.ModSounds;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.SitWhenOrderedToGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.OwnerHurtTargetGoal;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * Compagnon aquatique bipède. La forme 3D n'est pas ici : le client branche
 * le modèle Blockbench sur les {@code AnimationState} déclarés plus bas.
 */
public class KaiminusCompanion extends TamableAnimal {
	public static final byte BITE_EVENT = 70;
	public static final byte TAIL_EVENT = 71;
	public static final byte JET_EVENT = 72;

	private static final EntityDataAccessor<Integer> DATA_ORDER = SynchedEntityData.defineId(KaiminusCompanion.class, EntityDataSerializers.INT);

	/** États d'animation one-shot. Démarrés côté client dans {@link #handleEntityEvent(byte)}. */
	public final net.minecraft.world.entity.AnimationState biteAnimation = new net.minecraft.world.entity.AnimationState();
	public final net.minecraft.world.entity.AnimationState tailAnimation = new net.minecraft.world.entity.AnimationState();
	public final net.minecraft.world.entity.AnimationState waterJetAnimation = new net.minecraft.world.entity.AnimationState();

	private BlockPos guardAnchor;

	public KaiminusCompanion(EntityType<? extends KaiminusCompanion> type, Level level) {
		super(type, level);
		this.xpReward = 0;
		this.setPathfindingMalus(PathType.WATER, 0.0F);
		this.setPathfindingMalus(PathType.WATER_BORDER, 0.0F);
	}

	public static AttributeSupplier.Builder createAttributes() {
		return TamableAnimal.createAnimalAttributes()
				.add(Attributes.MAX_HEALTH, CompanionConfig.maxHealth)
				.add(Attributes.MOVEMENT_SPEED, CompanionConfig.movementSpeed)
				.add(Attributes.ATTACK_DAMAGE, CompanionConfig.attackDamage)
				.add(Attributes.ARMOR, CompanionConfig.armor)
				.add(Attributes.KNOCKBACK_RESISTANCE, CompanionConfig.knockbackResistance)
				.add(Attributes.STEP_HEIGHT, CompanionConfig.stepHeight)
				.add(Attributes.FOLLOW_RANGE, CompanionConfig.followRange)
				.add(Attributes.WATER_MOVEMENT_EFFICIENCY, 0.85);
	}

	@Override
	protected void registerGoals() {
		this.goalSelector.addGoal(0, new FloatGoal(this));
		this.goalSelector.addGoal(1, new SitWhenOrderedToGoal(this));
		this.goalSelector.addGoal(2, new CompanionAttackGoal(this));
		this.goalSelector.addGoal(3, new InterposeGoal(this));
		this.goalSelector.addGoal(4, new CompanionFollowGoal(this));
		this.goalSelector.addGoal(5, new CompanionPatrolGoal(this));
		this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 8.0F));
		this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));

		this.targetSelector.addGoal(1, new OwnerHurtByTargetGoal(this));
		this.targetSelector.addGoal(2, new OwnerHurtTargetGoal(this));
		this.targetSelector.addGoal(3, new ProtectOwnerTargetGoal(this));
		this.targetSelector.addGoal(4, new HurtByTargetGoal(this));
	}

	@Override
	protected PathNavigation createNavigation(Level level) {
		return new KaiminusNavigation(this, level);
	}

	@Override
	protected void defineSynchedData(SynchedEntityData.Builder builder) {
		super.defineSynchedData(builder);
		builder.define(DATA_ORDER, CompanionOrder.FOLLOW.ordinal());
	}

	@Override
	public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, net.minecraft.world.DifficultyInstance difficulty, EntitySpawnReason reason, SpawnGroupData spawnData) {
		SpawnGroupData data = super.finalizeSpawn(level, difficulty, reason, spawnData);
		if (!this.isTame()) {
			Player player = level.getLevel().getNearestPlayer(this, 8.0);
			if (player != null) {
				this.tame(player);
			}
		}
		return data;
	}

	@Override
	public void tame(Player player) {
		super.tame(player);
		this.setPersistenceRequired();
		this.setOrder(CompanionOrder.FOLLOW, true);
	}

	@Override
	public boolean canBreatheUnderwater() {
		return true;
	}

	@Override
	protected float getWaterSlowDown() {
		return 0.93F;
	}

	@Override
	public boolean removeWhenFarAway(double distanceSquared) {
		return false;
	}

	@Override
	public boolean isFood(ItemStack stack) {
		return false;
	}

	@Override
	public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob partner) {
		return null;
	}

	@Override
	public boolean canAttack(LivingEntity target) {
		if (this.getOrder() == CompanionOrder.STAY) {
			return false;
		}
		return super.canAttack(target);
	}

	@Override
	public boolean wantsToAttack(LivingEntity target, LivingEntity owner) {
		if (target == owner) {
			return false;
		}
		if (target instanceof TamableAnimal tamable && tamable.isOwnedBy(owner)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean shouldTryTeleportToOwner() {
		return this.getOrder() == CompanionOrder.FOLLOW && super.shouldTryTeleportToOwner();
	}

	public LivingEntity getOwnerLiving() {
		if (this.getOwner() instanceof LivingEntity living && living.isAlive()) {
			return living;
		}
		return null;
	}

	public CompanionOrder getOrder() {
		return CompanionOrder.byId(this.entityData.get(DATA_ORDER));
	}

	public void setOrder(CompanionOrder order, boolean refreshGuardAnchor) {
		this.entityData.set(DATA_ORDER, order.ordinal());
		this.setOrderedToSit(order == CompanionOrder.STAY);
		if (refreshGuardAnchor && order == CompanionOrder.GUARD) {
			this.guardAnchor = this.blockPosition();
		}
	}

	public BlockPos getGuardAnchor() {
		return this.guardAnchor == null ? this.blockPosition() : this.guardAnchor;
	}

	public boolean teleportNearOwner(LivingEntity owner) {
		if (owner.level() != this.level() || this.isLeashed() || this.isPassenger()) {
			return false;
		}
		BlockPos origin = owner.blockPosition();
		for (int attempt = 0; attempt < 12; attempt++) {
			int x = origin.getX() + this.random.nextInt(5) - 2;
			int z = origin.getZ() + this.random.nextInt(5) - 2;
			int y = origin.getY() + this.random.nextInt(3) - 1;
			if (this.canStandAt(new BlockPos(x, y, z), owner.isInWater())) {
				this.teleportTo(x + 0.5, y, z + 0.5);
				this.getNavigation().stop();
				return true;
			}
		}
		this.teleportTo(owner.getX() + 1.0, owner.getY(), owner.getZ());
		this.getNavigation().stop();
		return true;
	}

	private boolean canStandAt(BlockPos feet, boolean ownerInWater) {
		if (!this.level().hasChunk(SectionPos.blockToSectionCoord(feet.getX()), SectionPos.blockToSectionCoord(feet.getZ()))) {
			return false;
		}
		BlockPos groundPos = feet.below();
		BlockPos headPos = feet.above();
		BlockState ground = this.level().getBlockState(groundPos);
		boolean bodyFree = !this.blocksMovement(this.level().getBlockState(feet), feet);
		boolean headFree = !this.blocksMovement(this.level().getBlockState(headPos), headPos);
		if (!bodyFree || !headFree) {
			return false;
		}
		if (ownerInWater) {
			return true;
		}
		return this.blocksMovement(ground, groundPos) || ground.getFluidState().is(Fluids.WATER);
	}

	private boolean blocksMovement(BlockState state, BlockPos pos) {
		return !state.getCollisionShape(this.level(), pos).isEmpty();
	}

	/**
	 * Branche son + animation. Le byte est reçu par le client dans {@link #handleEntityEvent(byte)}.
	 */
	public void broadcastAttack(byte event, SoundEvent sound) {
		if (this.level() instanceof ServerLevel) {
			this.level().broadcastEntityEvent(this, event);
		}
		this.playSound(sound, 1.0F, 0.9F + this.random.nextFloat() * 0.2F);
		this.swingForAttack(InteractionHand.MAIN_HAND);
	}

	@Override
	public void handleEntityEvent(byte id) {
		switch (id) {
			case BITE_EVENT -> this.biteAnimation.start(this.tickCount);
			case TAIL_EVENT -> this.tailAnimation.start(this.tickCount);
			case JET_EVENT -> this.waterJetAnimation.start(this.tickCount);
			default -> super.handleEntityEvent(id);
		}
	}

	@Override
	public void aiStep() {
		super.aiStep();
		if (this.level().isClientSide()) {
			return;
		}
		this.setAggressive(this.getTarget() != null);
		if (this.tickCount % CompanionConfig.regenIntervalTicks != 0) {
			return;
		}
		boolean inCombat = this.getTarget() != null
				|| this.tickCount < this.getLastHurtByMobTimestamp() + CompanionConfig.combatTimeoutTicks;
		if (!inCombat && this.getHealth() < this.getMaxHealth()) {
			this.heal(CompanionConfig.regenAmount);
		}
	}

	@Override
	public InteractionResult mobInteract(Player player, InteractionHand hand) {
		ItemStack stack = player.getItemInHand(hand);
		if (this.level().isClientSide()) {
			return this.isOwnedBy(player) || !this.isTame() ? InteractionResult.SUCCESS : InteractionResult.PASS;
		}
		if (!this.isTame()) {
			this.tame(player);
			player.sendOverlayMessage(Component.translatable("message.kaiminus_companion.tamed"));
			return InteractionResult.SUCCESS_SERVER;
		}
		if (!this.isOwnedBy(player)) {
			return InteractionResult.PASS;
		}
		if (this.isHealItem(stack) && this.getHealth() < this.getMaxHealth()) {
			this.heal(CompanionConfig.healAmount);
			if (!player.hasInfiniteMaterials()) {
				stack.shrink(1);
			}
			this.playSound(ModSounds.EAT, 1.0F, 1.0F);
			return InteractionResult.SUCCESS_SERVER;
		}
		if (player.isShiftKeyDown() && stack.isEmpty()) {
			CompanionOrder next = this.getOrder().next();
			this.setOrder(next, true);
			player.sendOverlayMessage(Component.translatable(next.translationKey()));
			return InteractionResult.SUCCESS_SERVER;
		}
		return InteractionResult.PASS;
	}

	public boolean isHealItem(ItemStack stack) {
		return stack.is(Items.COD) || stack.is(Items.SALMON) || stack.is(Items.TROPICAL_FISH);
	}

	@Override
	protected void addAdditionalSaveData(ValueOutput output) {
		super.addAdditionalSaveData(output);
		output.putInt("Order", this.getOrder().ordinal());
		output.putBoolean("HasGuardAnchor", this.guardAnchor != null);
		if (this.guardAnchor != null) {
			output.putInt("GuardX", this.guardAnchor.getX());
			output.putInt("GuardY", this.guardAnchor.getY());
			output.putInt("GuardZ", this.guardAnchor.getZ());
		}
	}

	@Override
	protected void readAdditionalSaveData(ValueInput input) {
		super.readAdditionalSaveData(input);
		CompanionOrder order = CompanionOrder.byId(input.getInt("Order").orElse(0));
		this.setOrder(order, false);
		if (input.getBooleanOr("HasGuardAnchor", false)) {
			this.guardAnchor = new BlockPos(
					input.getInt("GuardX").orElse(this.getBlockX()),
					input.getInt("GuardY").orElse(this.getBlockY()),
					input.getInt("GuardZ").orElse(this.getBlockZ())
			);
		}
	}

	@Override
	protected SoundEvent getAmbientSound() {
		return this.isInWater() ? ModSounds.AMBIENT_WATER : ModSounds.AMBIENT;
	}

	@Override
	protected SoundEvent getHurtSound(DamageSource source) {
		return ModSounds.HURT;
	}

	@Override
	protected SoundEvent getDeathSound() {
		return ModSounds.DEATH;
	}
}
