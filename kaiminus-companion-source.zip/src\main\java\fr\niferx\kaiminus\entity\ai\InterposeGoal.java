package fr.niferx.kaiminus.entity.ai;

import java.util.EnumSet;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.CompanionOrder;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

/**
 * Se place sur le segment propriétaire → cible, devant le joueur,
 * tant que la cible n'est pas encore à portée de mêlée.
 */
public class InterposeGoal extends Goal {
	private final KaiminusCompanion companion;
	private int repathCooldown;

	public InterposeGoal(KaiminusCompanion companion) {
		this.companion = companion;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		return this.canKeepGuarding();
	}

	@Override
	public boolean canContinueToUse() {
		return this.canKeepGuarding();
	}

	private boolean canKeepGuarding() {
		if (this.companion.getOrder() == CompanionOrder.STAY || this.companion.isOrderedToSit()) {
			return false;
		}
		LivingEntity target = this.companion.getTarget();
		LivingEntity owner = this.companion.getOwnerLiving();
		return target != null
				&& owner != null
				&& target.isAlive()
				&& !this.companion.isWithinMeleeAttackRange(target);
	}

	@Override
	public void start() {
		this.repathCooldown = 0;
	}

	@Override
	public void stop() {
		this.companion.getNavigation().stop();
	}

	@Override
	public void tick() {
		LivingEntity target = this.companion.getTarget();
		LivingEntity owner = this.companion.getOwnerLiving();
		if (target == null || owner == null) {
			return;
		}
		this.companion.getLookControl().setLookAt(target, 30.0F, 30.0F);
		if (this.companion.distanceToSqr(owner) > square(CompanionConfig.teleportDistance)) {
			this.companion.teleportNearOwner(owner);
			this.repathCooldown = 0;
			return;
		}
		if (--this.repathCooldown > 0) {
			return;
		}
		this.repathCooldown = this.adjustedTickDelay(6);
		Vec3 point = shieldPoint(owner, target);
		double speed = this.companion.isInWater() ? CompanionConfig.swimSpeed : CompanionConfig.sprintSpeed;
		this.companion.getNavigation().moveTo(point.x, point.y, point.z, speed);
	}

	static Vec3 shieldPoint(LivingEntity owner, LivingEntity target) {
		double dx = target.getX() - owner.getX();
		double dz = target.getZ() - owner.getZ();
		double horizontal = Math.sqrt(dx * dx + dz * dz);
		if (horizontal < 0.001) {
			return owner.position();
		}
		double stand = Math.min(CompanionConfig.shieldDistance, horizontal * 0.5);
		return new Vec3(owner.getX() + dx / horizontal * stand, owner.getY(), owner.getZ() + dz / horizontal * stand);
	}

	private static double square(double value) {
		return value * value;
	}
}
