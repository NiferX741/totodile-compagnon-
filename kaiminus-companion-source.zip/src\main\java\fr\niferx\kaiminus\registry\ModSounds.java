package fr.niferx.kaiminus.registry;

import fr.niferx.kaiminus.KaiminusMod;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

/**
 * Sons du compagnon. Le cri est {@code sounds/cri.ogg}, joué à plusieurs hauteurs
 * depuis {@code sounds.json}. Les autres événements pointent encore vers des fichiers vanilla.
 * Les appels dans l'entité ({@code ModSounds.BITE}, etc.) restent les mêmes.
 */
public final class ModSounds {
	public static final SoundEvent AMBIENT = register("ambient");
	public static final SoundEvent AMBIENT_WATER = register("ambient_water");
	public static final SoundEvent HURT = register("hurt");
	public static final SoundEvent DEATH = register("death");
	public static final SoundEvent BITE = register("bite");
	public static final SoundEvent TAIL = register("tail");
	public static final SoundEvent WATER_JET = register("water_jet");
	public static final SoundEvent EAT = register("eat");

	private ModSounds() {
	}

	private static SoundEvent register(String path) {
		Identifier id = KaiminusMod.id(path);
		return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
	}

	public static void initialize() {
	}
}
