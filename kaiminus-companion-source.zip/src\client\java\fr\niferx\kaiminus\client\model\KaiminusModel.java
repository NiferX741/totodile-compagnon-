package fr.niferx.kaiminus.client.model;

import fr.niferx.kaiminus.KaiminusMod;
import fr.niferx.kaiminus.client.renderer.KaiminusRenderState;
import net.minecraft.client.animation.KeyframeAnimation;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.util.Mth;

/**
 * Voxel bipède : museau large, yeux sur les côtés, V jaune sur le poitrail,
 * crête rouge et queue à pointes. Les noms de parts animées restent stables
 * pour {@link KaiminusAnimations}.
 */
public class KaiminusModel extends EntityModel<KaiminusRenderState> {
	public static final ModelLayerLocation LAYER = new ModelLayerLocation(KaiminusMod.id("kaiminus"), "main");

	public static final String HEAD = "head";
	public static final String SNOUT = "snout";
	public static final String CREST = "crest";
	public static final String BODY = "body";
	public static final String TAIL = "tail";
	public static final String TAIL_MID = "tail_mid";
	public static final String TAIL_TIP = "tail_tip";
	public static final String LEFT_LEG = "left_leg";
	public static final String RIGHT_LEG = "right_leg";
	public static final String LEFT_ARM = "left_arm";
	public static final String RIGHT_ARM = "right_arm";

	private final ModelPart root;
	private final ModelPart head;
	private final ModelPart body;
	private final ModelPart tail;
	private final ModelPart tailMid;
	private final ModelPart tailTip;
	private final ModelPart leftLeg;
	private final ModelPart rightLeg;
	private final ModelPart leftArm;
	private final ModelPart rightArm;
	private final KeyframeAnimation bite;
	private final KeyframeAnimation tailSwing;
	private final KeyframeAnimation waterJet;

	public KaiminusModel(ModelPart root) {
		super(root);
		this.root = root;
		this.head = root.getChild(HEAD);
		this.body = root.getChild(BODY);
		this.tail = root.getChild(TAIL);
		this.tailMid = this.tail.getChild(TAIL_MID);
		this.tailTip = this.tailMid.getChild(TAIL_TIP);
		this.leftLeg = root.getChild(LEFT_LEG);
		this.rightLeg = root.getChild(RIGHT_LEG);
		this.leftArm = root.getChild(LEFT_ARM);
		this.rightArm = root.getChild(RIGHT_ARM);
		this.bite = KaiminusAnimations.BITE.bake(root);
		this.tailSwing = KaiminusAnimations.TAIL.bake(root);
		this.waterJet = KaiminusAnimations.WATER_JET.bake(root);
	}

	private static final float ARM_REST_X = 0.55F;

	public static LayerDefinition createBodyLayer() {
		MeshDefinition mesh = new MeshDefinition();
		PartDefinition root = mesh.getRoot();

		PartDefinition head = root.addOrReplaceChild(
				HEAD,
				CubeListBuilder.create().texOffs(0, 0).addBox(-5, -8, -4, 10, 8, 8),
				PartPose.offset(0.0F, 10.0F, -2.0F)
		);
		PartDefinition snout = head.addOrReplaceChild(
				SNOUT,
				CubeListBuilder.create().texOffs(0, 20).addBox(-4, -1, -7, 8, 4, 7),
				PartPose.offset(0.0F, -1.0F, -4.0F)
		);
		snout.addOrReplaceChild(
				"nose",
				CubeListBuilder.create().texOffs(40, 0).addBox(-2, -1, -2, 4, 2, 2),
				PartPose.offset(0.0F, -1.0F, -7.0F)
		);
		snout.addOrReplaceChild(
				"teeth",
				CubeListBuilder.create().texOffs(40, 8).addBox(-3, 0, -6, 6, 1, 6),
				PartPose.offset(0.0F, 3.0F, 0.0F)
		);
		head.addOrReplaceChild(
				"jaw",
				CubeListBuilder.create().texOffs(40, 16).addBox(-3.5F, 0, -5, 7, 2, 5),
				PartPose.offset(0.0F, 0.5F, -5.0F)
		);
		head.addOrReplaceChild(
				"eye_left",
				CubeListBuilder.create().texOffs(64, 0).addBox(0, -2, -2, 2, 4, 4),
				PartPose.offset(5.0F, -4.0F, -1.0F)
		);
		head.addOrReplaceChild(
				"pupil_left",
				CubeListBuilder.create().texOffs(80, 0).addBox(0, -1, -1, 1, 2, 2),
				PartPose.offset(7.0F, -3.6F, -1.2F)
		);
		head.addOrReplaceChild(
				"eye_right",
				CubeListBuilder.create().texOffs(64, 0).addBox(-2, -2, -2, 2, 4, 4),
				PartPose.offset(-5.0F, -4.0F, -1.0F)
		);
		head.addOrReplaceChild(
				"pupil_right",
				CubeListBuilder.create().texOffs(80, 0).addBox(-1, -1, -1, 1, 2, 2),
				PartPose.offset(-7.0F, -3.6F, -1.2F)
		);
		head.addOrReplaceChild(
				CREST,
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -5, -1, 2, 5, 3),
				PartPose.offsetAndRotation(0.0F, -7.0F, 2.0F, -0.7F, 0.0F, 0.0F)
		);
		head.addOrReplaceChild(
				"crest_back",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -4, -1, 2, 4, 3),
				PartPose.offsetAndRotation(0.0F, -5.0F, 4.0F, -1.05F, 0.0F, 0.0F)
		);

		PartDefinition body = root.addOrReplaceChild(
				BODY,
				CubeListBuilder.create().texOffs(0, 36).addBox(-6, -5, -4, 12, 10, 9),
				PartPose.offset(0.0F, 15.0F, 0.0F)
		);
		body.addOrReplaceChild(
				"chest_top",
				CubeListBuilder.create().texOffs(64, 16).addBox(-4, 0, -1, 8, 2, 1),
				PartPose.offset(0.0F, -3.0F, -4.0F)
		);
		body.addOrReplaceChild(
				"chest_mid",
				CubeListBuilder.create().texOffs(64, 16).addBox(-2.5F, 0, -1, 5, 2, 1),
				PartPose.offset(0.0F, -1.0F, -4.0F)
		);
		body.addOrReplaceChild(
				"chest_tip",
				CubeListBuilder.create().texOffs(64, 16).addBox(-1, 0, -1, 3, 2, 1),
				PartPose.offset(0.0F, 1.0F, -4.0F)
		);
		body.addOrReplaceChild(
				"back_spike",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -4, -1, 2, 4, 3),
				PartPose.offsetAndRotation(0.0F, -5.0F, 3.0F, -0.45F, 0.0F, 0.0F)
		);

		PartDefinition leftLeg = root.addOrReplaceChild(
				LEFT_LEG,
				CubeListBuilder.create().texOffs(0, 64).addBox(-3, 0, -3, 6, 10, 6),
				PartPose.offset(-3.4F, 14.0F, 1.0F)
		);
		PartDefinition rightLeg = root.addOrReplaceChild(
				RIGHT_LEG,
				CubeListBuilder.create().texOffs(0, 64).addBox(-3, 0, -3, 6, 10, 6),
				PartPose.offset(3.4F, 14.0F, 1.0F)
		);
		addClaws(leftLeg, 8.2F);
		addClaws(rightLeg, 8.2F);

		PartDefinition leftArm = root.addOrReplaceChild(
				LEFT_ARM,
				CubeListBuilder.create().texOffs(32, 80).addBox(-2, 0, -2, 4, 7, 4),
				PartPose.offsetAndRotation(-7.4F, 12.0F, -1.0F, ARM_REST_X, 0.2F, 0.0F)
		);
		PartDefinition rightArm = root.addOrReplaceChild(
				RIGHT_ARM,
				CubeListBuilder.create().texOffs(32, 80).addBox(-2, 0, -2, 4, 7, 4),
				PartPose.offsetAndRotation(7.4F, 12.0F, -1.0F, ARM_REST_X, -0.2F, 0.0F)
		);
		addClaws(leftArm, 5.4F);
		addClaws(rightArm, 5.4F);

		PartDefinition tail = root.addOrReplaceChild(
				TAIL,
				CubeListBuilder.create().texOffs(48, 36).addBox(-3, -3, 0, 6, 6, 6),
				PartPose.offsetAndRotation(0.0F, 17.0F, 5.0F, -0.45F, 0.0F, 0.0F)
		);
		tail.addOrReplaceChild(
				"spike",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -5, -1, 2, 5, 3),
				PartPose.offset(0.0F, -2.0F, 1.5F)
		);
		PartDefinition tailMid = tail.addOrReplaceChild(
				TAIL_MID,
				CubeListBuilder.create().texOffs(48, 56).addBox(-2, -2, 0, 4, 4, 6),
				PartPose.offset(0.0F, 0.5F, 5.5F)
		);
		tailMid.addOrReplaceChild(
				"spike",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -4, -1, 2, 4, 3),
				PartPose.offset(0.0F, -1.5F, 1.5F)
		);
		PartDefinition tailTip = tailMid.addOrReplaceChild(
				TAIL_TIP,
				CubeListBuilder.create().texOffs(80, 40).addBox(-1, -1, 0, 3, 3, 5),
				PartPose.offset(0.0F, 0.4F, 5.5F)
		);
		tailTip.addOrReplaceChild(
				"spike",
				CubeListBuilder.create().texOffs(96, 0).addBox(-1, -3, -1, 2, 3, 2),
				PartPose.offset(0.5F, -1.0F, 1.0F)
		);

		return LayerDefinition.create(mesh, 128, 128);
	}

	private static void addClaws(PartDefinition limb, float y) {
		limb.addOrReplaceChild("claw_0", CubeListBuilder.create().texOffs(64, 28).addBox(0, 0, -2, 1, 2, 2), PartPose.offset(-1.6F, y, -1.4F));
		limb.addOrReplaceChild("claw_1", CubeListBuilder.create().texOffs(64, 28).addBox(0, 0, -2, 1, 2, 2), PartPose.offset(-0.5F, y, -1.8F));
		limb.addOrReplaceChild("claw_2", CubeListBuilder.create().texOffs(64, 28).addBox(0, 0, -2, 1, 2, 2), PartPose.offset(0.6F, y, -1.4F));
	}

	@Override
	public void setupAnim(KaiminusRenderState state) {
		this.root.getAllParts().forEach(ModelPart::resetPose);
		if (state.waterJetAnimation.isStarted()) {
			this.waterJet.apply(state.waterJetAnimation, state.ageInTicks);
		} else if (state.tailAnimation.isStarted()) {
			this.tailSwing.apply(state.tailAnimation, state.ageInTicks);
		} else if (state.biteAnimation.isStarted()) {
			this.bite.apply(state.biteAnimation, state.ageInTicks);
		} else if (state.sitting) {
			this.applySit();
		} else if (state.swimming) {
			this.applySwim(state);
		} else {
			this.applyWalk(state);
		}
		this.head.xRot += state.xRot * Mth.DEG_TO_RAD;
		this.head.yRot += state.yRot * Mth.DEG_TO_RAD;
	}

	private void applyWalk(KaiminusRenderState state) {
		float swing = Mth.cos(state.walkAnimationPos * 0.6662F);
		float amount = state.walkAnimationSpeed;
		this.leftLeg.xRot = swing * 1.1F * amount;
		this.rightLeg.xRot = -swing * 1.1F * amount;
		this.leftArm.xRot = ARM_REST_X - swing * 0.45F * amount;
		this.rightArm.xRot = ARM_REST_X + swing * 0.45F * amount;
		this.tail.yRot = Mth.cos(state.ageInTicks * 0.12F) * 0.18F;
		this.tailMid.yRot = this.tail.yRot * 0.6F;
	}

	private void applySwim(KaiminusRenderState state) {
		this.body.xRot = 18.0F * Mth.DEG_TO_RAD;
		this.head.xRot = -10.0F * Mth.DEG_TO_RAD;
		this.leftLeg.xRot = 0.7F;
		this.rightLeg.xRot = 0.7F;
		this.leftArm.xRot = 0.4F;
		this.rightArm.xRot = 0.4F;
		float wave = Mth.cos(state.ageInTicks * 0.35F);
		this.tail.yRot = wave * 0.45F;
		this.tailMid.yRot = wave * 0.35F;
		this.tailTip.yRot = wave * 0.25F;
	}

	private void applySit() {
		this.body.y += 3.0F;
		this.head.y += 3.0F;
		this.leftLeg.xRot = -1.15F;
		this.rightLeg.xRot = -1.15F;
		this.leftArm.xRot = -0.4F;
		this.rightArm.xRot = -0.4F;
		this.tail.xRot = -0.4F;
	}
}
