package fr.niferx.kaiminus.entity.ai;

import java.util.EnumSet;
import java.util.List;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.CompanionOrder;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.NeutralMob;
import net.minecraft.world.entity.ai.goal.target.TargetGoal;
import net.minecraft.world.entity.monster.Creeper;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;

/**
 * Choisit une cible proche du propriétaire : un hostile qui l'attaque,
 * ou un monstre toujours agressif qui entre dans le rayon de menace.
 * Les neutres (enderman, piglin, loup) ne sont pris que s'ils s'en prennent au joueur.
 */
public class ProtectOwnerTargetGoal extends TargetGoal {
	private final KaiminusCompanion companion;
	private LivingEntity pending;

	public ProtectOwnerTargetGoal(KaiminusCompanion companion) {
		super(companion, false);
		this.companion = companion;
		this.setFlags(EnumSet.of(Flag.TARGET));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		if (this.companion.getOrder() == CompanionOrder.STAY || !this.companion.isTame()) {
			return false;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		if (owner == null) {
			return false;
		}
		this.pending = this.findThreat(owner);
		return this.pending != null;
	}

	@Override
	public boolean canContinueToUse() {
		LivingEntity target = this.companion.getTarget();
		LivingEntity owner = this.companion.getOwnerLiving();
		if (target == null || owner == null || !target.isAlive() || this.companion.getOrder() == CompanionOrder.STAY) {
			return false;
		}
		double leash = CompanionConfig.threatRange + 6.0;
		return this.companion.canAttack(target) && target.distanceToSqr(owner) <= leash * leash;
	}

	@Override
	public void start() {
		this.companion.setTarget(this.pending);
		this.pending = null;
	}

	@Override
	public void stop() {
		this.pending = null;
		this.companion.setTarget(null);
	}

	private LivingEntity findThreat(LivingEntity owner) {
		AABB area = owner.getBoundingBox().inflate(CompanionConfig.threatRange);
		List<Mob> candidates = this.companion.level().getEntitiesOfClass(Mob.class, area, mob -> this.isThreat(mob, owner));
		Mob best = null;
		int bestScore = Integer.MIN_VALUE;
		double bestDistance = Double.MAX_VALUE;
		for (Mob mob : candidates) {
			int score = 0;
			if (mob.getTarget() == owner) {
				score += 100;
			}
			if (owner.getLastHurtByMob() == mob) {
				score += 80;
			}
			if (mob.getLastHurtMob() == owner) {
				score += 40;
			}
			double distance = mob.distanceToSqr(owner);
			if (best == null || score > bestScore || (score == bestScore && distance < bestDistance)) {
				best = mob;
				bestScore = score;
				bestDistance = distance;
			}
		}
		return best;
	}

	private boolean isThreat(Mob mob, LivingEntity owner) {
		if (!mob.isAlive() || mob == this.companion || !this.companion.canAttack(mob)) {
			return false;
		}
		if (mob.distanceToSqr(owner) > CompanionConfig.threatRange * CompanionConfig.threatRange) {
			return false;
		}
		if (mob instanceof Creeper && mob.distanceToSqr(owner) > 16.0) {
			return false;
		}
		boolean engaging = mob.getTarget() == owner || owner.getLastHurtByMob() == mob || mob.getLastHurtMob() == owner;
		boolean alwaysHostile = mob instanceof Enemy && !(mob instanceof NeutralMob);
		return engaging || alwaysHostile;
	}
}
