package fr.niferx.kaiminus.client.model;

import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;

import org.joml.Matrix4f;
import org.joml.Quaternionf;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.logging.LogUtils;

import fr.niferx.kaiminus.KaiminusMod;
import fr.niferx.kaiminus.client.renderer.KaiminusRenderState;
import net.minecraft.client.Minecraft;
import net.minecraft.util.Mth;
import org.slf4j.Logger;

/**
 * Maillage skinné lu depuis le GLB Meshy. Le fichier n'a aucune animation :
 * la marche, la nage, l'attente et les attaques tournent les os à la main.
 */
public final class KaiminusRig {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final int TAIL = 1;
	private static final int LEFT_ARM = 5;
	private static final int RIGHT_ARM = 9;
	private static final int JAW = 13;
	private static final int HEAD = 14;
	private static final int SPINE = 18;
	private static final int LEFT_KNEE = 21;
	private static final int LEFT_LEG = 22;
	private static final int RIGHT_KNEE = 25;
	private static final int RIGHT_LEG = 26;
	private static final int HIPS = 28;

	private static volatile KaiminusRig loaded;
	private static volatile boolean failed;

	private final int nodeCount;
	private final int[] parent;
	private final float[] translation;
	private final float[] rotation;
	private final float[] scale;
	private final Matrix4f[] matrix;
	private final int jointCount;
	private final int[] jointNode;
	private final float[] inverseBind;
	private final int vertexCount;
	private final float[] bindPos;
	private final float[] bindNrm;
	private final float[] uv;
	private final int[] joints;
	private final float[] weights;
	private final int[] indices;
	private float[] lidClosed = new float[0];
	private int[] lidJoints = new int[0];
	private float[] lidWeights = new float[0];
	private final float[] lidPosed = new float[48];
	private float blinkAmount;
	private float lidU = 0.02F;
	private float lidV = 0.02F;

	private KaiminusRig(
			int nodeCount,
			int[] parent,
			float[] translation,
			float[] rotation,
			float[] scale,
			Matrix4f[] matrix,
			int jointCount,
			int[] jointNode,
			float[] inverseBind,
			int vertexCount,
			float[] bindPos,
			float[] bindNrm,
			float[] uv,
			int[] joints,
			float[] weights,
			int[] indices
	) {
		this.nodeCount = nodeCount;
		this.parent = parent;
		this.translation = translation;
		this.rotation = rotation;
		this.scale = scale;
		this.matrix = matrix;
		this.jointCount = jointCount;
		this.jointNode = jointNode;
		this.inverseBind = inverseBind;
		this.vertexCount = vertexCount;
		this.bindPos = bindPos;
		this.bindNrm = bindNrm;
		this.uv = uv;
		this.joints = joints;
		this.weights = weights;
		this.indices = indices;
	}

	public static KaiminusRig get() {
		if (loaded != null || failed) {
			return loaded;
		}
		synchronized (KaiminusRig.class) {
			if (loaded == null && !failed) {
				try {
					loaded = load();
					LOGGER.info("Kaiminus: modèle GLB chargé ({} sommets)", loaded.vertexCount);
				} catch (Exception exception) {
					failed = true;
					LOGGER.error("Kaiminus: échec du chargement du GLB, retour au modèle voxel", exception);
				}
			}
		}
		return loaded;
	}

	public void render(KaiminusRenderState state, PoseStack.Pose pose, VertexConsumer consumer, int color, int overlay, int light) {
		float[] posed = new float[vertexCount * 3];
		float[] normals = new float[vertexCount * 3];
		skin(state, posed, normals);
		// Le pipeline entity_cutout est en QUADS : (v0,v1,v2) (v2,v3,v0).
		// On répète le troisième sommet pour que le second triangle soit dégénéré.
		for (int triangle = 0; triangle < indices.length; triangle += 3) {
			emit(consumer, pose, posed, normals, color, overlay, light, indices[triangle]);
			emit(consumer, pose, posed, normals, color, overlay, light, indices[triangle + 1]);
			emit(consumer, pose, posed, normals, color, overlay, light, indices[triangle + 2]);
			emit(consumer, pose, posed, normals, color, overlay, light, indices[triangle + 2]);
		}
		if (blinkAmount > 0.04F && lidClosed.length == 48) {
			for (int lid = 0; lid < 4; lid++) {
				float nx = lid < 2 ? (lid == 0 ? 1.0F : -1.0F) : 0.0F;
				float nz = lid < 2 ? 0.0F : 1.0F;
				for (int corner = 0; corner < 4; corner++) {
					int p = lid * 12 + corner * 3;
					consumer.addVertex(pose, lidPosed[p], lidPosed[p + 1], lidPosed[p + 2])
							.setColor(color)
							.setUv(lidU, lidV)
							.setOverlay(overlay)
							.setLight(light)
							.setNormal(pose, nx, 0.0F, nz);
				}
			}
		}
	}

	private void emit(VertexConsumer consumer, PoseStack.Pose pose, float[] posed, float[] normals, int color, int overlay, int light, int index) {
		int position = index * 3;
		int tex = index * 2;
		consumer.addVertex(pose, posed[position], posed[position + 1], posed[position + 2])
				.setColor(color)
				.setUv(uv[tex], uv[tex + 1])
				.setOverlay(overlay)
				.setLight(light)
				.setNormal(pose, normals[position], normals[position + 1], normals[position + 2]);
	}

	private void skin(KaiminusRenderState state, float[] outPos, float[] outNrm) {
		float[] extraX = new float[nodeCount];
		float[] extraY = new float[nodeCount];
		float[] extraZ = new float[nodeCount];
		pose(state, extraX, extraY, extraZ);

		Matrix4f[] global = new Matrix4f[nodeCount];
		for (int node = 0; node < nodeCount; node++) {
			global(node, global, extraX, extraY, extraZ);
		}

		float[] skin = new float[jointCount * 16];
		float[] tmp = new float[16];
		Matrix4f inverse = new Matrix4f();
		Matrix4f combined = new Matrix4f();
		for (int joint = 0; joint < jointCount; joint++) {
			System.arraycopy(inverseBind, joint * 16, tmp, 0, 16);
			inverse.set(tmp);
			combined.set(global[jointNode[joint]]).mul(inverse);
			combined.get(tmp);
			System.arraycopy(tmp, 0, skin, joint * 16, 16);
		}

		for (int vertex = 0; vertex < vertexCount; vertex++) {
			int p = vertex * 3;
			int j = vertex * 4;
			float x = bindPos[p];
			float y = bindPos[p + 1];
			float z = bindPos[p + 2];
			float nx = bindNrm[p];
			float ny = bindNrm[p + 1];
			float nz = bindNrm[p + 2];
			float ox = 0.0F;
			float oy = 0.0F;
			float oz = 0.0F;
			float onx = 0.0F;
			float ony = 0.0F;
			float onz = 0.0F;
			float weightSum = 0.0F;
			for (int influence = 0; influence < 4; influence++) {
				float weight = weights[j + influence];
				if (weight <= 0.0001F) {
					continue;
				}
				int slot = joints[j + influence];
				if (slot < 0 || slot >= jointCount) {
					continue;
				}
				int m = slot * 16;
				float m00 = skin[m];
				float m01 = skin[m + 1];
				float m02 = skin[m + 2];
				float m10 = skin[m + 4];
				float m11 = skin[m + 5];
				float m12 = skin[m + 6];
				float m20 = skin[m + 8];
				float m21 = skin[m + 9];
				float m22 = skin[m + 10];
				float m30 = skin[m + 12];
				float m31 = skin[m + 13];
				float m32 = skin[m + 14];
				ox += weight * (m00 * x + m10 * y + m20 * z + m30);
				oy += weight * (m01 * x + m11 * y + m21 * z + m31);
				oz += weight * (m02 * x + m12 * y + m22 * z + m32);
				onx += weight * (m00 * nx + m10 * ny + m20 * nz);
				ony += weight * (m01 * nx + m11 * ny + m21 * nz);
				onz += weight * (m02 * nx + m12 * ny + m22 * nz);
				weightSum += weight;
			}
			if (weightSum <= 0.0001F) {
				ox = x;
				oy = y;
				oz = z;
				onx = nx;
				ony = ny;
				onz = nz;
			}
			float length = Mth.sqrt(onx * onx + ony * ony + onz * onz);
			if (length > 1.0E-4F) {
				onx /= length;
				ony /= length;
				onz /= length;
			} else {
				onx = 0.0F;
				ony = 1.0F;
				onz = 0.0F;
			}
			outPos[p] = ox;
			outPos[p + 1] = oy;
			outPos[p + 2] = oz;
			outNrm[p] = onx;
			outNrm[p + 1] = ony;
			outNrm[p + 2] = onz;
		}
		poseLids(state.ageInTicks, skin);
	}

	private void poseLids(float age, float[] skinMats) {
		float phase = age % 55.0F;
		blinkAmount = phase < 8.0F ? Mth.sin(phase / 8.0F * Mth.PI) : 0.0F;
		if (((int) (age / 55.0F)) % 3 == 0 && phase >= 10.0F && phase < 16.0F) {
			blinkAmount = Math.max(blinkAmount, Mth.sin((phase - 10.0F) / 6.0F * Mth.PI));
		}
		if (lidClosed.length != 48) {
			return;
		}
		for (int lid = 0; lid < 4; lid++) {
			float topLeft = lidClosed[lid * 12 + 1];
			float topRight = lidClosed[lid * 12 + 4];
			for (int corner = 0; corner < 4; corner++) {
				int o = lid * 12 + corner * 3;
				float x = lidClosed[o];
				float y = lidClosed[o + 1];
				float z = lidClosed[o + 2];
				if (corner >= 2) {
					float top = corner == 2 ? topRight : topLeft;
					y = top + (y - top) * blinkAmount;
				}
				float ox = 0.0F;
				float oy = 0.0F;
				float oz = 0.0F;
				float weightSum = 0.0F;
				for (int influence = 0; influence < 4; influence++) {
					float weight = lidWeights[lid * 4 + influence];
					if (weight <= 0.0001F) {
						continue;
					}
					int slot = lidJoints[lid * 4 + influence];
					int m = slot * 16;
					ox += weight * (skinMats[m] * x + skinMats[m + 4] * y + skinMats[m + 8] * z + skinMats[m + 12]);
					oy += weight * (skinMats[m + 1] * x + skinMats[m + 5] * y + skinMats[m + 9] * z + skinMats[m + 13]);
					oz += weight * (skinMats[m + 2] * x + skinMats[m + 6] * y + skinMats[m + 10] * z + skinMats[m + 14]);
					weightSum += weight;
				}
				if (weightSum <= 0.0001F) {
					ox = x;
					oy = y;
					oz = z;
				}
				lidPosed[o] = ox;
				lidPosed[o + 1] = oy;
				lidPosed[o + 2] = oz;
			}
		}
	}

	private void pose(KaiminusRenderState state, float[] extraX, float[] extraY, float[] extraZ) {
		if (nodeCount <= HIPS) {
			return;
		}
		float run = Mth.clamp((state.moveSpeed - 0.15F) / 0.14F, 0.0F, 1.0F);
		float limb = Mth.cos(state.walkAnimationPos * (0.6662F + run * 0.35F)) * state.walkAnimationSpeed;
		float legAmp = 0.48F + run * 0.38F;
		float armAmp = 0.42F + run * 0.4F;
		extraX[LEFT_LEG] = limb * legAmp;
		extraX[RIGHT_LEG] = -limb * legAmp;
		extraX[LEFT_KNEE] = Math.max(0.0F, limb) * (0.32F + run * 0.28F);
		extraX[RIGHT_KNEE] = Math.max(0.0F, -limb) * (0.32F + run * 0.28F);
		extraZ[LEFT_ARM] = limb * armAmp;
		extraZ[RIGHT_ARM] = limb * armAmp;
		extraX[TAIL] = Mth.sin(state.ageInTicks * (0.16F + run * 0.1F)) * (0.06F + state.walkAnimationSpeed * (0.1F + run * 0.08F));
		extraY[SPINE] = Mth.sin(state.ageInTicks * 0.14F) * state.walkAnimationSpeed * 0.05F;

		float headYaw = Mth.wrapDegrees(state.yRot - state.bodyRot) * Mth.DEG_TO_RAD;
		float headPitch = state.xRot * Mth.DEG_TO_RAD;
		extraZ[HEAD] = Mth.clamp(headYaw * 0.18F, -0.2F, 0.2F);
		extraX[HEAD] = Mth.clamp(headPitch * 0.1F, -0.12F, 0.12F);

		if (state.swimming) {
			extraX[SPINE] += 0.5F;
			extraX[LEFT_LEG] *= 0.4F;
			extraX[RIGHT_LEG] *= 0.4F;
			float paddle = Mth.cos(state.ageInTicks * 0.3F);
			extraZ[LEFT_ARM] = 0.3F + paddle * 0.28F;
			extraZ[RIGHT_ARM] = 0.3F - paddle * 0.28F;
		}
		if (state.sitting) {
			extraX[LEFT_LEG] = 0.0F;
			extraX[RIGHT_LEG] = 0.0F;
			extraX[LEFT_KNEE] = 0.0F;
			extraX[RIGHT_KNEE] = 0.0F;
			extraZ[LEFT_ARM] = 0.0F;
			extraZ[RIGHT_ARM] = 0.0F;
			extraX[SPINE] = 0.0F;
			extraY[SPINE] = 0.0F;
			extraX[TAIL] = Mth.sin(state.ageInTicks * 0.08F) * 0.05F;
		}

		float bite = pulse(state.biteAnimation, state.ageInTicks, 360.0F);
		float tail = pulse(state.tailAnimation, state.ageInTicks, 420.0F);
		float jet = pulse(state.waterJetAnimation, state.ageInTicks, 400.0F);
		float mouth = bite > 0.0F ? 0.0F : mouthCycle(state.ageInTicks);
		float open = Math.max(mouth, Math.max(bite, jet * 0.7F));
		extraX[JAW] = -0.30F + open * 0.46F;
		extraX[HEAD] += bite * 0.2F - jet * 0.1F;
		extraZ[LEFT_ARM] += bite * 0.42F;
		extraZ[RIGHT_ARM] += bite * 0.42F;
		extraY[TAIL] += tail * 0.65F;
		extraY[SPINE] += tail * 0.16F;
	}

	private static float mouthCycle(float age) {
		float phase = age % 90.0F;
		if (phase < 18.0F) {
			return Mth.sin(phase / 18.0F * Mth.PI);
		}
		if (phase >= 24.0F && phase < 38.0F) {
			return Mth.sin((phase - 24.0F) / 14.0F * Mth.PI) * 0.7F;
		}
		return 0.0F;
	}

	private static float pulse(net.minecraft.world.entity.AnimationState animation, float ageInTicks, float durationMillis) {
		if (!animation.isStarted()) {
			return 0.0F;
		}
		float elapsed = animation.getTimeInMillis(ageInTicks);
		if (elapsed < 0.0F || elapsed >= durationMillis) {
			return 0.0F;
		}
		return Mth.sin((elapsed / durationMillis) * Mth.PI);
	}

	private Matrix4f global(int node, Matrix4f[] cache, float[] extraX, float[] extraY, float[] extraZ) {
		if (cache[node] != null) {
			return cache[node];
		}
		Matrix4f local = new Matrix4f();
		if (matrix[node] != null) {
			local.set(matrix[node]);
		} else {
			int r = node * 4;
			int t = node * 3;
			Quaternionf rotationQuat = new Quaternionf(rotation[r], rotation[r + 1], rotation[r + 2], rotation[r + 3]);
			if (extraX[node] != 0.0F || extraY[node] != 0.0F || extraZ[node] != 0.0F) {
				rotationQuat.mul(new Quaternionf().rotateX(extraX[node]).rotateY(extraY[node]).rotateZ(extraZ[node]));
			}
			local.translation(translation[t], translation[t + 1], translation[t + 2])
					.rotate(rotationQuat)
					.scale(scale[t], scale[t + 1], scale[t + 2]);
		}
		if (parent[node] >= 0) {
			cache[node] = new Matrix4f(global(parent[node], cache, extraX, extraY, extraZ)).mul(local);
		} else {
			cache[node] = local;
		}
		return cache[node];
	}

	private static KaiminusRig load() throws IOException {
		byte[] file;
		try (InputStream in = Minecraft.getInstance().getResourceManager().getResourceOrThrow(KaiminusMod.id("models/kaiminus.glb")).open()) {
			file = in.readAllBytes();
		}
		ByteBuffer header = ByteBuffer.wrap(file).order(ByteOrder.LITTLE_ENDIAN);
		if (header.getInt(0) != 0x46546C67) {
			throw new IOException("en-tête GLB invalide");
		}
		int jsonLength = header.getInt(12);
		int binChunk = 20 + jsonLength;
		int binLength = header.getInt(binChunk);
		int binOffset = binChunk + 8;
		String json = new String(file, 20, jsonLength, StandardCharsets.UTF_8);
		JsonObject root = JsonParser.parseString(json).getAsJsonObject();
		JsonArray nodes = root.getAsJsonArray("nodes");
		JsonArray accessors = root.getAsJsonArray("accessors");
		JsonArray bufferViews = root.getAsJsonArray("bufferViews");
		byte[] bin = new byte[binLength];
		System.arraycopy(file, binOffset, bin, 0, binLength);

		int nodeCount = nodes.size();
		int[] parent = new int[nodeCount];
		java.util.Arrays.fill(parent, -1);
		float[] translation = new float[nodeCount * 3];
		float[] rotation = new float[nodeCount * 4];
		float[] scale = new float[nodeCount * 3];
		Matrix4f[] matrix = new Matrix4f[nodeCount];
		for (int i = 0; i < nodeCount; i++) {
			JsonObject node = nodes.get(i).getAsJsonObject();
			rotation[i * 4 + 3] = 1.0F;
			scale[i * 3] = 1.0F;
			scale[i * 3 + 1] = 1.0F;
			scale[i * 3 + 2] = 1.0F;
			if (node.has("matrix")) {
				matrix[i] = new Matrix4f().set(readFloatArray(node.getAsJsonArray("matrix")));
			} else {
				readVec(node, "translation", translation, i * 3, 3);
				readVec(node, "rotation", rotation, i * 4, 4);
				readVec(node, "scale", scale, i * 3, 3);
			}
			if (node.has("children")) {
				for (var child : node.getAsJsonArray("children")) {
					parent[child.getAsInt()] = i;
				}
			}
		}

		JsonObject skin = root.getAsJsonArray("skins").get(0).getAsJsonObject();
		JsonArray jointArray = skin.getAsJsonArray("joints");
		int jointCount = jointArray.size();
		int[] jointNode = new int[jointCount];
		for (int i = 0; i < jointCount; i++) {
			jointNode[i] = jointArray.get(i).getAsInt();
		}
		float[] inverseBind = readAccessor(accessors, bufferViews, bin, skin.get("inverseBindMatrices").getAsInt());

		JsonObject primitive = root.getAsJsonArray("meshes").get(0).getAsJsonObject().getAsJsonArray("primitives").get(0).getAsJsonObject();
		JsonObject attributes = primitive.getAsJsonObject("attributes");
		float[] bindPos = readAccessor(accessors, bufferViews, bin, attributes.get("POSITION").getAsInt());
		float[] bindNrm = readAccessor(accessors, bufferViews, bin, attributes.get("NORMAL").getAsInt());
		float[] uv = readAccessor(accessors, bufferViews, bin, attributes.get("TEXCOORD_0").getAsInt());
		int[] joints = readUnsignedBytes(accessors, bufferViews, bin, attributes.get("JOINTS_0").getAsInt());
		float[] weights = readAccessor(accessors, bufferViews, bin, attributes.get("WEIGHTS_0").getAsInt());
		int[] indices = readIndices(accessors, bufferViews, bin, primitive.get("indices").getAsInt());
		KaiminusRig rig = new KaiminusRig(nodeCount, parent, translation, rotation, scale, matrix, jointCount, jointNode, inverseBind, bindPos.length / 3, bindPos, bindNrm, uv, joints, weights, indices);
		rig.initLids(root, bin, bindPos, joints, weights);
		return rig;
	}

	private void initLids(JsonObject root, byte[] bin, float[] pos, int[] joints, float[] weights) {
		float[][] lids = {
				{0.318F, 1.60F, -0.06F, 0.318F, 1.60F, 0.30F, 0.318F, 1.42F, 0.30F, 0.318F, 1.42F, -0.06F},
				{-0.318F, 1.60F, 0.30F, -0.318F, 1.60F, -0.06F, -0.318F, 1.42F, -0.06F, -0.318F, 1.42F, 0.30F},
				{0.05F, 1.50F, 0.795F, 0.20F, 1.50F, 0.795F, 0.20F, 1.35F, 0.795F, 0.05F, 1.35F, 0.795F},
				{-0.20F, 1.50F, 0.795F, -0.05F, 1.50F, 0.795F, -0.05F, 1.35F, 0.795F, -0.20F, 1.35F, 0.795F}
		};
		lidClosed = new float[48];
		lidJoints = new int[16];
		lidWeights = new float[16];
		int verts = pos.length / 3;
		for (int lid = 0; lid < 4; lid++) {
			System.arraycopy(lids[lid], 0, lidClosed, lid * 12, 12);
			float cx = (lids[lid][0] + lids[lid][3] + lids[lid][6] + lids[lid][9]) * 0.25F;
			float cy = (lids[lid][1] + lids[lid][4] + lids[lid][7] + lids[lid][10]) * 0.25F;
			float cz = (lids[lid][2] + lids[lid][5] + lids[lid][8] + lids[lid][11]) * 0.25F;
			int best = 0;
			float bestDistance = Float.MAX_VALUE;
			for (int vertex = 0; vertex < verts; vertex++) {
				float dx = pos[vertex * 3] - cx;
				float dy = pos[vertex * 3 + 1] - cy;
				float dz = pos[vertex * 3 + 2] - cz;
				float distance = dx * dx + dy * dy + dz * dz;
				if (distance < bestDistance) {
					bestDistance = distance;
					best = vertex;
				}
			}
			System.arraycopy(joints, best * 4, lidJoints, lid * 4, 4);
			System.arraycopy(weights, best * 4, lidWeights, lid * 4, 4);
		}
		try {
			JsonObject image = root.getAsJsonArray("images").get(0).getAsJsonObject();
			JsonObject view = root.getAsJsonArray("bufferViews").get(image.get("bufferView").getAsInt()).getAsJsonObject();
			int offset = view.has("byteOffset") ? view.get("byteOffset").getAsInt() : 0;
			int length = view.get("byteLength").getAsInt();
			java.awt.image.BufferedImage picture = javax.imageio.ImageIO.read(new java.io.ByteArrayInputStream(bin, offset, length));
			if (picture != null) {
				int width = picture.getWidth();
				int height = picture.getHeight();
				for (int py = 8; py < height - 8 && lidU < 0.05F; py += 6) {
					for (int px = 8; px < width - 8; px += 6) {
						int argb = picture.getRGB(px, py);
						int red = (argb >> 16) & 255;
						int green = (argb >> 8) & 255;
						int blue = argb & 255;
						if (red < 90 && green > 130 && blue > 180 && blue > red + 70) {
							lidU = px / (float) (width - 1);
							lidV = py / (float) (height - 1);
							break;
						}
					}
				}
			}
		} catch (Exception exception) {
			LOGGER.warn("Kaiminus: paupières sans couleur de peau", exception);
		}
	}

	private static void readVec(JsonObject node, String name, float[] dest, int offset, int count) {
		if (!node.has(name)) {
			return;
		}
		JsonArray array = node.getAsJsonArray(name);
		for (int i = 0; i < count; i++) {
			dest[offset + i] = array.get(i).getAsFloat();
		}
	}

	private static float[] readFloatArray(JsonArray array) {
		float[] values = new float[array.size()];
		for (int i = 0; i < values.length; i++) {
			values[i] = array.get(i).getAsFloat();
		}
		return values;
	}

	private static float[] readAccessor(JsonArray accessors, JsonArray bufferViews, byte[] bin, int index) {
		Accessor accessor = Accessor.of(accessors.get(index).getAsJsonObject(), bufferViews);
		float[] out = new float[accessor.count * accessor.components];
		ByteBuffer buffer = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN);
		for (int i = 0; i < accessor.count; i++) {
			int at = accessor.base + i * accessor.stride;
			for (int c = 0; c < accessor.components; c++) {
				out[i * accessor.components + c] = readComponent(buffer, at + c * accessor.componentBytes, accessor.componentType);
			}
		}
		return out;
	}

	private static int[] readUnsignedBytes(JsonArray accessors, JsonArray bufferViews, byte[] bin, int index) {
		Accessor accessor = Accessor.of(accessors.get(index).getAsJsonObject(), bufferViews);
		int[] out = new int[accessor.count * accessor.components];
		for (int i = 0; i < out.length; i++) {
			int element = i / accessor.components;
			int component = i % accessor.components;
			out[i] = bin[accessor.base + element * accessor.stride + component] & 0xFF;
		}
		return out;
	}

	private static int[] readIndices(JsonArray accessors, JsonArray bufferViews, byte[] bin, int index) {
		Accessor accessor = Accessor.of(accessors.get(index).getAsJsonObject(), bufferViews);
		int[] out = new int[accessor.count];
		ByteBuffer buffer = ByteBuffer.wrap(bin).order(ByteOrder.LITTLE_ENDIAN);
		for (int i = 0; i < accessor.count; i++) {
			int at = accessor.base + i * accessor.stride;
			out[i] = accessor.componentType == 5125 ? buffer.getInt(at) : buffer.getShort(at) & 0xFFFF;
		}
		return out;
	}

	private static float readComponent(ByteBuffer buffer, int offset, int componentType) {
		return switch (componentType) {
			case 5126 -> buffer.getFloat(offset);
			case 5121 -> (buffer.get(offset) & 0xFF) / 255.0F;
			case 5123 -> (buffer.getShort(offset) & 0xFFFF) / 65535.0F;
			default -> throw new IllegalArgumentException("composant glTF " + componentType);
		};
	}

	private record Accessor(int count, int components, int componentType, int componentBytes, int base, int stride) {
		static Accessor of(JsonObject accessor, JsonArray bufferViews) {
			int components = switch (accessor.get("type").getAsString()) {
				case "SCALAR" -> 1;
				case "VEC2" -> 2;
				case "VEC3" -> 3;
				case "VEC4" -> 4;
				case "MAT4" -> 16;
				default -> throw new IllegalArgumentException(accessor.get("type").getAsString());
			};
			int componentType = accessor.get("componentType").getAsInt();
			int componentBytes = componentType == 5126 || componentType == 5125 ? 4 : 2;
			if (componentType == 5120 || componentType == 5121) {
				componentBytes = 1;
			}
			JsonObject view = bufferViews.get(accessor.get("bufferView").getAsInt()).getAsJsonObject();
			int viewOffset = view.has("byteOffset") ? view.get("byteOffset").getAsInt() : 0;
			int accessorOffset = accessor.has("byteOffset") ? accessor.get("byteOffset").getAsInt() : 0;
			int stride = view.has("byteStride") ? view.get("byteStride").getAsInt() : components * componentBytes;
			return new Accessor(accessor.get("count").getAsInt(), components, componentType, componentBytes, viewOffset + accessorOffset, stride);
		}
	}
}
