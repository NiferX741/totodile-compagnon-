package fr.niferx.kaiminus.entity;

public enum CompanionOrder {
	FOLLOW("message.kaiminus_companion.order.follow"),
	STAY("message.kaiminus_companion.order.stay"),
	GUARD("message.kaiminus_companion.order.guard");

	private final String translationKey;

	CompanionOrder(String translationKey) {
		this.translationKey = translationKey;
	}

	public String translationKey() {
		return this.translationKey;
	}

	public CompanionOrder next() {
		CompanionOrder[] values = values();
		return values[(this.ordinal() + 1) % values.length];
	}

	public static CompanionOrder byId(int id) {
		CompanionOrder[] values = values();
		if (id < 0 || id >= values.length) {
			return FOLLOW;
		}
		return values[id];
	}
}
