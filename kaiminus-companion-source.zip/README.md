# Kaiminus Companion

Compagnon aquatique pour Minecraft **26.3** (Fabric). Il suit le joueur, nage avec lui et se place entre lui et les menaces.

Identifiant du mod : `kaiminus_companion`  
Version : `0.1.0`  
Jar : `build/libs/kaiminus-companion-0.1.0.jar`

La forme affichée en jeu est le modèle Meshy 800 faces (`models/kaiminus.glb`). Le fichier ne contient aucune clip : la marche, la course, la nage, la morsure, la mâchoire et le clignement des yeux sont joués sur les os. Si le GLB ne charge pas, le voxel de secours reprend le rendu.

## Installation

Instance Fabric **26.3**, avec :

- Fabric Loader `0.20.1` ou plus récent
- Fabric API pour la 26.3
- Java 25

Copier le jar dans le dossier `mods`.

Pour le recompiler :

```powershell
$env:JAVA_HOME = "C:\Users\nifer\.jdks\temurin-25\jdk-25.0.5+8"
cd C:\Users\nifer\KaiminusCompanion
.\gradlew.bat jar
```

Le jar jouable est `build/libs/kaiminus-companion-0.1.0.jar`.

## En jeu

| Action | Effet |
|---|---|
| Œuf de Kaiminus, posé au sol | Se fend en trois étapes, puis le compagnon sort. Environ 3 minutes, ou 1 minute sur du sable ou contre de l’eau |
| Coffres d’épave et de ruine sous-marine | L’œuf à poser s’y trouve rarement |
| Œuf d’apparition, onglet des œufs | Fait apparaître le compagnon tout de suite, en créatif |
| `/summon kaiminus_companion:kaiminus` | Même chose, en commande |
| Clic droit | L’apprivoise s’il ne l’est pas encore |
| Accroupi + clic droit à main vide | Change l’ordre : suivi, attente, garde |
| Morue, saumon ou poisson tropical | Rend 6 points de vie |

Au spawn, s’il y a un joueur à 8 blocs ou moins, le compagnon s’apprivoise tout seul. Un message au-dessus de la barre d’action confirme l’apprivoisement et chaque changement d’ordre.

Il ne despawn pas, et il est sauvegardé avec son propriétaire, son ordre et son point de garde.

### Ordres

- **Suivi.** Il reste entre 3 et 5 blocs. Au-delà de 10 blocs il accélère. Au-delà de 18 blocs, ou si son chemin n’avance plus pendant environ 2 secondes, il se téléporte près du joueur. Quand le joueur est immobile, il patrouille dans un rayon de 2,2 blocs.
- **Attente.** Il s’assoit, ne suit plus et ne combat plus.
- **Garde.** Il ne suit plus. Il patrouille dans un rayon de 4 blocs autour de l’endroit où l’ordre a été donné. Il rejoint le joueur seulement s’il y a un combat et que le joueur est à plus de 18 blocs.

### Combat

Il vise d’abord ce qui frappe le joueur, puis ce que le joueur frappe, puis un monstre hostile dans un rayon de 8 blocs. Les créatures neutres (enderman, piglin, loup) ne sont prises que si elles s’en prennent au joueur. Un creeper n’est visé qu’à moins de 4 blocs.

Dès qu’une cible est choisie, le compagnon se place sur la ligne entre le joueur et cette cible, à environ 2,2 blocs du joueur, puis frappe au contact.

- **Morsure :** 6 dégâts, petit recul. Une fois par seconde.
- **Coup de queue :** un coup sur deux. 5 dégâts, recul plus fort.
- **Jet d’eau :** cône de 6 blocs, 2 dégâts et recul. Dans l’eau, ou si le joueur brûle. Le jet éteint le feu du joueur, du compagnon et des cibles touchées. Recharge : 2 secondes.

### Eau et survie

Il respire sous l’eau et cherche son chemin aussi bien sur terre que dans l’eau. Il nage plus vite qu’il ne marche. Hors combat, il régénère 1 point de vie toutes les 2 secondes. Le combat compte encore 10 secondes après le dernier coup reçu.

Valeurs de départ : 40 points de vie, 4 d’armure, 25 % de résistance au recul, un bloc de hauteur de pas.

## Réglages

Tout est dans `src/main/java/fr/niferx/kaiminus/CompanionConfig.java`.

La vie, l’armure, la vitesse de base, la hauteur de pas et la portée de détection sont lues **au lancement du jeu**. Changer ces champs demande un redémarrage. Les distances, dégâts des coups, cooldowns et la régénération sont lus en jeu en continu.

| Champ | Défaut | Rôle |
|---|---|---|
| `maxHealth` | 40 | Vie maximale |
| `armor` | 4 | Armure |
| `movementSpeed` | 0.32 | Vitesse de base |
| `followStartDistance` | 5 | Distance à partir de laquelle il se remet en route |
| `followStopDistance` | 3 | Distance à laquelle il s’arrête |
| `sprintSpeed` | 1.5 | Vitesse quand le joueur est à plus de 10 blocs |
| `swimSpeed` | 1.65 | Vitesse dans l’eau |
| `teleportDistance` | 18 | Téléportation |
| `threatRange` | 8 | Rayon de détection des hostiles |
| `shieldDistance` | 2.2 | Distance devant le joueur pendant un combat |
| `biteDamage` / `tailDamage` | 6 / 5 | Dégâts des coups |
| `waterJetRange` | 6 | Portée du jet |
| `healAmount` | 6 | Soin d’un poisson |
| `regenAmount` | 1 toutes les 40 ticks | Régénération hors combat |

## Brancher son modèle

Blockbench : export **Java Entity**, mappings **Mojmap**.

1. Remplacer le corps de `KaiminusModel.createBodyLayer()` par l’export. Les noms de pièces lus par le code sont `head`, `snout`, `crest`, `body`, `tail`, `tail_mid`, `tail_tip`, `left_leg`, `right_leg`, `left_arm`, `right_arm`.
2. Mettre la texture en `assets/kaiminus_companion/textures/entity/kaiminus.png` (64×64 aujourd’hui). Le chemin est `KaiminusRenderer.TEXTURE`.
3. Remplacer `BITE`, `TAIL` et `WATER_JET` dans `KaiminusAnimations`. `setupAnim` les joue dans cet ordre : jet, queue, morsure, puis la nage ou la marche. La nage et la marche sont calculées dans le code (`applySwim`, `applyWalk`) : on peut les remplacer par deux animations Blockbench au même endroit.

Les attaques préviennent le client par un octet d’entité : 70 morsure, 71 queue, 72 jet. `handleEntityEvent` démarre l’`AnimationState`, et `KaiminusRenderer.extractRenderState` le copie vers le rendu. Pour une animation de plus : un `AnimationState` sur l’entité, un octet libre, la copie dans `KaiminusRenderState`, puis l’`AnimationDefinition`.

## Sons

`ModSounds` enregistre `ambient`, `ambient_water`, `hurt`, `death`, `bite`, `tail`, `water_jet` et `eat`. Le cri (`sounds/cri.ogg`) est joué au hasard à cinq hauteurs sur terre et à trois hauteurs plus graves sous l’eau. Les autres événements pointent encore vers des sons vanilla.

## Fichiers

```
src/main/java/fr/niferx/kaiminus/
  KaiminusMod.java                  démarrage
  CompanionConfig.java              réglages
  entity/KaiminusCompanion.java     entité, ordres, soins, NBT
  entity/CompanionOrder.java        suivi, attente, garde
  entity/ai/                        suivi, interposition, attaque, cible, patrouille, navigation
  registry/                         entité, œuf, sons
src/client/java/fr/niferx/kaiminus/client/
  model/                            modèle et animations
  renderer/                         rendu et état visuel
```

L’ordre est synchronisé par les données d’entité vanilla. Les coups le sont par les octets d’entité. Il n’y a pas de paquet réseau à part.
