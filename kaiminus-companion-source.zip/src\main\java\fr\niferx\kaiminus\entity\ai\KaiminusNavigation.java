package fr.niferx.kaiminus.entity.ai;

import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.navigation.AmphibiousPathNavigation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.AmphibiousNodeEvaluator;
import net.minecraft.world.level.pathfinder.PathFinder;

/**
 * Cherche un chemin aussi bien sur terre que dans l'eau.
 * {@code prefersShallowSwimming = false} pour pouvoir suivre le joueur en profondeur.
 */
public final class KaiminusNavigation extends AmphibiousPathNavigation {
	public KaiminusNavigation(Mob mob, Level level) {
		super(mob, level);
	}

	@Override
	protected boolean canUpdatePath() {
		return true;
	}

	@Override
	protected PathFinder createPathFinder(int maxVisitedNodes) {
		this.nodeEvaluator = new AmphibiousNodeEvaluator(false);
		return new PathFinder(this.nodeEvaluator, maxVisitedNodes);
	}
}
