package fr.niferx.kaiminus;

/**
 * Réglages du compagnon. Vie, dégâts et vitesse sont lus au démarrage,
 * quand les attributs de l'entité sont enregistrés. Les distances sont lues
 * à chaque tick par les goals.
 */
public final class CompanionConfig {
	public static double maxHealth = 40.0;
	public static double attackDamage = 6.0;
	public static double movementSpeed = 0.32;
	public static double armor = 4.0;
	public static double knockbackResistance = 0.25;
	public static double stepHeight = 1.0;
	public static double followRange = 32.0;

	/** Le suivi démarre au-delà de cette distance, et s'arrête en dessous de {@link #followStopDistance}. */
	public static double followStartDistance = 5.0;
	public static double followStopDistance = 3.0;
	public static double followSpeed = 1.15;
	public static double sprintSpeed = 1.5;
	public static double swimSpeed = 1.65;
	public static double teleportDistance = 18.0;

	public static double threatRange = 8.0;
	public static double shieldDistance = 2.2;
	public static double patrolRadius = 2.2;
	public static double guardPatrolRadius = 4.0;

	public static float biteDamage = 6.0F;
	public static float tailDamage = 5.0F;
	public static double biteKnockback = 0.35;
	public static double tailKnockback = 1.35;
	public static int meleeCooldownTicks = 20;

	public static float waterJetDamage = 2.0F;
	public static double waterJetRange = 6.0;
	public static double waterJetKnockback = 0.95;
	public static int waterJetCooldownTicks = 40;

	public static int regenIntervalTicks = 40;
	public static float regenAmount = 1.0F;
	public static int combatTimeoutTicks = 200;
	public static float healAmount = 6.0F;

	private CompanionConfig() {
	}
}
