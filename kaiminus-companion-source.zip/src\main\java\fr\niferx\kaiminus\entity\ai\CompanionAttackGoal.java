package fr.niferx.kaiminus.entity.ai;

import java.util.EnumSet;
import java.util.List;

import fr.niferx.kaiminus.CompanionConfig;
import fr.niferx.kaiminus.entity.CompanionOrder;
import fr.niferx.kaiminus.entity.KaiminusCompanion;
import fr.niferx.kaiminus.registry.ModSounds;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Morsure et coup de queue au contact. Jet d'eau en cône si la cible (ou le compagnon)
 * est dans l'eau, ou si le propriétaire brûle.
 */
public class CompanionAttackGoal extends Goal {
	private final KaiminusCompanion companion;
	private int meleeCooldown;
	private int jetCooldown;
	private boolean nextStrikeIsTail;

	public CompanionAttackGoal(KaiminusCompanion companion) {
		this.companion = companion;
		this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
	}

	@Override
	public boolean requiresUpdateEveryTick() {
		return true;
	}

	@Override
	public boolean canUse() {
		return this.readyToAct();
	}

	@Override
	public boolean canContinueToUse() {
		return this.meleeCooldown > 0 || this.readyToAct();
	}

	private boolean readyToAct() {
		if (this.companion.getOrder() == CompanionOrder.STAY || this.companion.isOrderedToSit()) {
			return false;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		if (owner != null && owner.isOnFire() && this.jetCooldown <= 0) {
			return true;
		}
		LivingEntity target = this.companion.getTarget();
		if (target == null || !target.isAlive()) {
			return false;
		}
		if (this.companion.isWithinMeleeAttackRange(target)) {
			return true;
		}
		return this.jetCooldown <= 0 && this.inJetRange(target) && (this.companion.isInWater() || target.isInWater());
	}

	@Override
	public void stop() {
		this.companion.getNavigation().stop();
	}

	@Override
	public void tick() {
		if (this.meleeCooldown > 0) {
			this.meleeCooldown--;
		}
		if (this.jetCooldown > 0) {
			this.jetCooldown--;
		}
		if (!(this.companion.level() instanceof ServerLevel serverLevel)) {
			return;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		LivingEntity target = this.companion.getTarget();
		if (target != null) {
			this.companion.getLookControl().setLookAt(target, 30.0F, 30.0F);
		}
		this.companion.getNavigation().stop();

		boolean ownerOnFire = owner != null && owner.getRemainingFireTicks() > 0;
		if (ownerOnFire && this.jetCooldown <= 0) {
			this.fireJet(serverLevel, owner);
			return;
		}
		if (target != null && target.isAlive() && this.companion.isWithinMeleeAttackRange(target) && this.meleeCooldown <= 0) {
			this.melee(serverLevel, target);
			return;
		}
		if (target != null && this.jetCooldown <= 0 && this.inJetRange(target) && (this.companion.isInWater() || target.isInWater())) {
			this.fireJet(serverLevel, owner);
		}
	}

	private void melee(ServerLevel level, LivingEntity target) {
		boolean tail = this.nextStrikeIsTail;
		this.nextStrikeIsTail = !this.nextStrikeIsTail;
		float damage = tail ? CompanionConfig.tailDamage : CompanionConfig.biteDamage;
		double knockback = tail ? CompanionConfig.tailKnockback : CompanionConfig.biteKnockback;
		var source = this.companion.damageSources().mobAttack(this.companion);
		boolean hurt = target.hurtServer(level, source, damage);
		if (hurt) {
			target.knockback(knockback, this.companion.getX() - target.getX(), this.companion.getZ() - target.getZ(), source, damage);
			this.companion.setLastHurtMob(target);
		}
		this.companion.broadcastAttack(tail ? KaiminusCompanion.TAIL_EVENT : KaiminusCompanion.BITE_EVENT, tail ? ModSounds.TAIL : ModSounds.BITE);
		this.meleeCooldown = CompanionConfig.meleeCooldownTicks + (tail ? 4 : 0);
	}

	private void fireJet(ServerLevel level, LivingEntity owner) {
		if (owner != null && owner.getRemainingFireTicks() > 0) {
			owner.clearFire();
		}
		if (this.companion.getRemainingFireTicks() > 0) {
			this.companion.clearFire();
		}
		Vec3 forward = Vec3.directionFromRotation(this.companion.getXRot(), this.companion.getYHeadRot());
		AABB area = this.companion.getBoundingBox().inflate(CompanionConfig.waterJetRange, 1.5, CompanionConfig.waterJetRange);
		List<LivingEntity> hits = level.getEntitiesOfClass(LivingEntity.class, area, this::canSplash);
		for (LivingEntity hit : hits) {
			if (!this.inCone(forward, hit)) {
				continue;
			}
			var source = this.companion.damageSources().mobAttack(this.companion);
			hit.hurtServer(level, source, CompanionConfig.waterJetDamage);
			hit.knockback(CompanionConfig.waterJetKnockback, this.companion.getX() - hit.getX(), this.companion.getZ() - hit.getZ(), source, CompanionConfig.waterJetDamage);
			if (hit.getRemainingFireTicks() > 0) {
				hit.clearFire();
			}
		}
		for (int i = 1; i <= 4; i++) {
			Vec3 point = this.companion.getEyePosition().add(forward.scale(i * 0.9));
			level.sendParticles(ParticleTypes.SPLASH, point.x, point.y, point.z, 8, 0.2, 0.15, 0.2, 0.05);
		}
		this.companion.broadcastAttack(KaiminusCompanion.JET_EVENT, ModSounds.WATER_JET);
		this.jetCooldown = CompanionConfig.waterJetCooldownTicks;
	}

	private boolean canSplash(LivingEntity entity) {
		if (!entity.isAlive() || entity == this.companion) {
			return false;
		}
		LivingEntity owner = this.companion.getOwnerLiving();
		if (owner == null) {
			return entity != this.companion;
		}
		return this.companion.wantsToAttack(entity, owner);
	}

	private boolean inJetRange(LivingEntity target) {
		return this.companion.distanceToSqr(target) <= square(CompanionConfig.waterJetRange);
	}

	private boolean inCone(Vec3 forward, LivingEntity target) {
		Vec3 to = target.getEyePosition().subtract(this.companion.getEyePosition());
		double distance = to.length();
		if (distance < 0.4 || distance > CompanionConfig.waterJetRange) {
			return false;
		}
		return forward.dot(to.normalize()) > 0.5;
	}

	private static double square(double value) {
		return value * value;
	}
}
